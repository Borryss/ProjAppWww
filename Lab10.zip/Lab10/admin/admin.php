<?php
// =======================================
// Dołączenie konfiguracji oraz uruchomienie sesji
// =======================================
include('../cfg.php');  // Dołączenie pliku konfiguracyjnego
session_start();  // Uruchomienie sesji, aby przechować informacje o zalogowaniu


// =======================================
// Logowanie użytkownika - obsługa formularza logowania
// =======================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login_email'], $_POST['login_pass'])) {
    // Sprawdzanie, czy podany email i hasło są zgodne z zapisanymi w konfiguracji
    if ($_POST['login_email'] === $login && $_POST['login_pass'] === $pass) {
        $_SESSION['is_logged_in'] = true;  // Ustalenie, że użytkownik jest zalogowany
    } else {
        // Jeżeli dane logowania są błędne, wyświetlamy formularz logowania
        echo "<p>Błędny login lub hasło</p>";
        echo FormularzLogowania();  // Wywołanie funkcji formularza logowania
        exit;
    }
}

// =======================================
// Sprawdzenie, czy użytkownik jest zalogowany
// =======================================
if (!isset($_SESSION['is_logged_in']) || $_SESSION['is_logged_in'] !== true) {
    // Jeżeli użytkownik nie jest zalogowany, wyświetlamy formularz logowania
    echo FormularzLogowania();
    exit;
}

// =======================================
// Obsługa różnych akcji (dodawanie, edytowanie, usuwanie) na podstawie parametru 'action'
// =======================================
if ($_GET['action'] === 'add') {
    // Jeżeli akcja to 'add', wywołujemy funkcję dodania nowej podstrony
    DodajNowaPodstrone();
}

if ($_GET['action'] === 'edit' && isset($_GET['id'])) {
    // Jeżeli akcja to 'edit' i istnieje parametr 'id', wywołujemy funkcję edytowania podstrony
    EdytujPodstrone(intval($_GET['id']));
}

if ($_GET['action'] === 'delete' && isset($_GET['id'])) {
    // Jeżeli akcja to 'delete' i istnieje parametr 'id', usuwamy podstronę
    $id = intval($_GET['id']);  // Zabezpieczenie ID przed SQL Injection
    $query = "DELETE FROM page_list WHERE id = $id LIMIT 1";  // Zapytanie SQL do usunięcia podstrony
    mysqli_query($conn, $query);  // Wykonanie zapytania SQL
    echo "Podstrona została usunięta.";  // Informacja o usunięciu
}

// =======================================
// Funkcja generująca formularz logowania
// =======================================
function FormularzLogowania() {
    // Zwraca formularz logowania HTML
    return '
    <div class="logowanie">
        <h1 class="heading">Panel CMS:</h1>
        <div class="logowanie">
            <form method="post" name="LoginForm" enctype="multipart/form-data" action="' . $_SERVER['REQUEST_URI'] . '">
                <table class="logowanie">
                    <tr><td class="log4_t">[email]</td><td><input type="text" name="login_email" class="logowanie" /></td></tr>
                    <tr><td class="log4_t">[haslo]</td><td><input type="password" name="login_pass" class="logowanie" /></td></tr>
                    <tr><td>&nbsp;</td><td><input type="submit" name="x1_submit" class="logowanie" value="Zaloguj" /></td></tr>
                </table>
            </form>
        </div>
    </div>';
}

// =======================================
// Panel administracyjny - linki nawigacyjne
// =======================================
echo '<h1>Panel Administracyjny</h1>';
echo '<a href="admin.php?action=add">Dodaj Podstronę</a><br>';
echo '<a href="admin.php?action=list">Lista Podstron</a><br>';

// Linki do zarządzania kategoriami
echo '<h2>Zarządzanie Kategoriami</h2>';
echo '<a href="admin.php?action=add_category">Dodaj Kategorię</a><br>';
echo '<a href="admin.php?action=list_categories">Lista Kategorii</a><br>';


// =======================================
// Funkcja wyświetlająca listę podstron
// =======================================
function ListaPodstron() {
    global $conn;
    $query = "SELECT id, page_title FROM page_list ORDER BY id ASC";  // Zapytanie do bazy danych
    $result = mysqli_query($conn, $query);  // Wykonanie zapytania

    // Wyświetlanie wyników w tabeli HTML
    echo '<table>';
    echo '<tr><th>ID</th><th>Tytuł</th><th>Akcje</th></tr>';

    while ($row = mysqli_fetch_assoc($result)) {
        // Iteracja po wynikach zapytania i wyświetlanie każdej podstrony
        echo '<tr>';
        echo '<td>' . $row['id'] . '</td>';
        echo '<td>' . $row['page_title'] . '</td>';
        echo '<td>
                <a href="admin.php?action=edit&id=' . $row['id'] . '">Edytuj</a> |
                <a href="admin.php?action=delete&id=' . $row['id'] . '">Usuń</a>
              </td>';
        echo '</tr>';
    }

    echo '</table>';
}

// =======================================
// Funkcja edytująca podstronę na podstawie ID
// =======================================
function EdytujPodstrone($id) {
    global $conn;
    $query = "SELECT * FROM page_list WHERE id = $id LIMIT 1";  // Zapytanie do bazy danych
    $result = mysqli_query($conn, $query);  // Wykonanie zapytania
    $row = mysqli_fetch_assoc($result);  // Pobranie danych podstrony

    // Formularz edycji podstrony
    echo '<form method="post" action="admin.php?action=save&id=' . $id . '">';
    echo '<label>Tytuł:</label><input type="text" name="page_title" value="' . htmlspecialchars($row['page_title']) . '" /><br>';
    echo '<label>Treść:</label><textarea name="page_content">' . htmlspecialchars($row['page_content']) . '</textarea><br>';
    echo '<label>Aktywna:</label><input type="checkbox" name="status" ' . ($row['status'] == 1 ? 'checked' : '') . ' /><br>';
    echo '<input type="submit" value="Zapisz">';
    echo '</form>';
}

// =======================================
// Funkcja dodająca nową podstronę
// =======================================
function DodajNowaPodstrone() {
    // Formularz dodawania nowej podstrony
    echo '<form method="post" action="admin.php?action=add">';
    echo '<label>Tytuł:</label><input type="text" name="page_title" /><br>';
    echo '<label>Treść:</label><textarea name="page_content"></textarea><br>';
    echo '<label>Aktywna:</label><input type="checkbox" name="status" /><br>';
    echo '<input type="submit" value="Dodaj">';
    echo '</form>';
}

// =======================================
// Pokaz Kategorie
// =======================================
function PokazKategorie() {
    global $conn;

    // Zapytanie SQL do pobrania kategorii
    $query = "SELECT * FROM kategorki WHERE matka = 0 ORDER BY id ASC LIMIT 50"; // Wyświetlamy kategorie główne
    $result = mysqli_query($conn, $query);

    echo '<h2>Lista Kategorii</h2>';
    echo '<table style="width: 100%; border-collapse: collapse;">';
    echo '<tr style="background-color: #111; color: #39FF14; text-align: left;">
            <th style="padding: 8px;">ID</th>
            <th style="padding: 8px;">Nazwa</th>
            <th style="padding: 8px;">Akcje</th>
          </tr>';

    while ($row = mysqli_fetch_assoc($result)) {
        echo '<tr style="background-color: #1a1a1a; color: #39FF14;">';
        echo '<td style="padding: 8px;">' . htmlspecialchars($row['id']) . '</td>';
        echo '<td style="padding: 8px;">' . htmlspecialchars($row['nazwa']) . '</td>';
        echo '<td style="padding: 8px;">
                <a href="admin.php?action=edit_category&id=' . intval($row['id']) . '" style="color: #39FF14; text-decoration: none;">Edytuj</a> |
                <a href="admin.php?action=delete_category&id=' . intval($row['id']) . '" style="color: #FF5555; text-decoration: none;">Usuń</a> |
                <a href="admin.php?action=view_subcategories&id=' . intval($row['id']) . '" style="color: #39FF14; text-decoration: none;"></a>
              </td>';
        echo '</tr>';

        // Wypisanie podkategorii (dzieci)
        $query2 = "SELECT * FROM kategorki WHERE matka = " . $row['id'] . " ORDER BY id ASC";
        $result2 = mysqli_query($conn, $query2);
        while ($sub_row = mysqli_fetch_assoc($result2)) {
            echo '<tr style="background-color: #333; color: #39FF14;">';
            echo '<td style="padding: 8px;">&nbsp;&nbsp;&nbsp;' . htmlspecialchars($sub_row['id']) . '</td>';
            echo '<td style="padding: 8px;">' . htmlspecialchars($sub_row['nazwa']) . '</td>';
            echo '<td style="padding: 8px;">
                    <a href="admin.php?action=edit_category&id=' . intval($sub_row['id']) . '" style="color: #39FF14; text-decoration: none;">Edytuj</a> |
                    <a href="admin.php?action=delete_category&id=' . intval($sub_row['id']) . '" style="color: #FF5555; text-decoration: none;">Usuń</a>
                  </td>';
            echo '</tr>';
        }
    }

    echo '</table>';
}


function DodajKategorie() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Pobieranie danych z formularza
        global $conn;
        $nazwa = mysqli_real_escape_string($conn, $_POST['nazwa']);
        $matka = intval($_POST['matka']);

        // Wstawianie danych do bazy
        $query = "INSERT INTO kategorki (nazwa, matka) VALUES ('$nazwa', $matka)";
        if (mysqli_query($conn, $query)) {
            echo "Kategoria została dodana.";
        } else {
            echo "Błąd podczas dodawania kategorii: " . mysqli_error($conn);
        }
    }

    // Wyświetlanie formularza
    echo '<h2>Dodaj Nową Kategorię</h2>';
    echo '<form method="post" action="admin.php?action=add_category">';
    echo '<label>Nazwa:</label><input type="text" name="nazwa" required /><br>';
    echo '<label>Matka (ID kategorii głównej):</label><input type="number" name="matka" value="0" /><br>';
    echo '<input type="submit" value="Dodaj kategorię">';
    echo '</form>';
}

function EdytujKategorie($id) {
    global $conn;
    $query = "SELECT * FROM kategorki WHERE id = $id LIMIT 1";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    echo '<h2>Edytuj Kategorię</h2>';
    echo '<form method="post" action="admin.php?action=save_category&id=' . intval($id) . '">';
    echo '<label>Nazwa:</label><input type="text" name="nazwa" value="' . htmlspecialchars($row['nazwa']) . '" required /><br>';
    echo '<label>Matka (ID kategorii głównej):</label><input type="number" name="matka" value="' . intval($row['matka']) . '" /><br>';
    echo '<input type="submit" value="Zapisz">';
    echo '</form>';
}

if (isset($_GET['action']) && $_GET['action'] === 'save_category' && isset($_GET['id']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_GET['id']);
    $nazwa = mysqli_real_escape_string($conn, $_POST['nazwa']);
    $matka = intval($_POST['matka']);

    $query = "UPDATE kategorki SET nazwa = '$nazwa', matka = $matka WHERE id = $id";
    if (mysqli_query($conn, $query)) {
        echo "Kategoria została zaktualizowana.";
    } else {
        echo "Błąd podczas aktualizacji: " . mysqli_error($conn);
    }
}

if (isset($_GET['action']) && $_GET['action'] === 'delete_category' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $query = "DELETE FROM kategorki WHERE id = $id LIMIT 1";
    if (mysqli_query($conn, $query)) {
        echo "Kategoria została usunięta.";
    } else {
        echo "Błąd podczas usuwania: " . mysqli_error($conn);
    }
}

if (isset($_GET['action']) && $_GET['action'] === 'add_category') {
    DodajKategorie();
}

if (isset($_GET['action']) && $_GET['action'] === 'list_categories') {
    PokazKategorie();
}

if (isset($_GET['action']) && $_GET['action'] === 'edit_category') {
    EdytujKategorie(intval($_GET['id']));
}

// =======================================
// Zapisywanie zmian (aktualizacja) w podstronie
// =======================================
if ($_GET['action'] === 'save' && isset($_GET['id']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    // Pobieranie danych z formularza edycji
    $id = intval($_GET['id']);  // Zabezpieczenie ID przed SQL Injection
    $title = mysqli_real_escape_string($conn, $_POST['page_title']);  // Ochrona przed SQL Injection
    $content = mysqli_real_escape_string($conn, $_POST['page_content']);  // Ochrona przed SQL Injection
    $status = isset($_POST['status']) ? 1 : 0;  // Ustawienie statusu podstrony

    // Zapytanie do bazy danych w celu aktualizacji podstrony
    $query = "UPDATE page_list SET page_title = '$title', page_content = '$content', status = $status WHERE id = $id";
    if (mysqli_query($conn, $query)) {
        echo "Podstrona została zaktualizowana.";  // Potwierdzenie sukcesu
    } else {
        echo "Błąd podczas aktualizacji: " . mysqli_error($conn);  // Błąd, jeżeli zapytanie nie zostało wykonane poprawnie
    }
}

// =======================================
// Obsługa akcji po kliknięciu linku w panelu administracyjnym
// =======================================
if (isset($_GET['action'])) {
    if ($_GET['action'] === 'list') {
        ListaPodstron();  // Wywołanie funkcji wyświetlającej listę podstron
    } elseif ($_GET['action'] === 'add' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        // Obsługa dodawania nowej podstrony
        $title = $_POST['page_title'];
        $content = $_POST['page_content'];
        $status = isset($_POST['status']) ? 1 : 0;

        // Zapytanie SQL do dodania nowej podstrony
        $query = "INSERT INTO page_list (page_title, page_content, status) VALUES ('$title', '$content', $status)";
        mysqli_query($conn, $query);  // Wykonanie zapytania
        echo "Podstrona została dodana.";  // Potwierdzenie dodania
    } elseif ($_GET['action'] === 'delete' && isset($_GET['id'])) {
        // Usuwanie podstrony
        $id = intval($_GET['id']);
        $query = "DELETE FROM page_list WHERE id = $id LIMIT 1";
        mysqli_query($conn, $query);  // Wykonanie zapytania
        echo "Podstrona została usunięta.";  // Potwierdzenie usunięcia
    }
}






?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Administracyjny</title>
    <link rel="stylesheet" href="../css/CSS.css">  <!-- Dołączenie pliku CSS -->
</head>
<body>
</body>
</html>
