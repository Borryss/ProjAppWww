<?php
include('../cfg.php');
session_start();



if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login_email'], $_POST['login_pass'])) {
    if ($_POST['login_email'] === $login && $_POST['login_pass'] === $pass) {
        $_SESSION['is_logged_in'] = true;
    } else {
        echo "<p>Błędny login lub hasło</p>";
        echo FormularzLogowania();
        exit;
    }
}


if (!isset($_SESSION['is_logged_in']) || $_SESSION['is_logged_in'] !== true) {
    echo FormularzLogowania();
    exit;
}

if ($_GET['action'] === 'add') {
    DodajNowaPodstrone();
}

if ($_GET['action'] === 'edit' && isset($_GET['id'])) {
    EdytujPodstrone(intval($_GET['id']));
}

if ($_GET['action'] === 'delete' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $query = "DELETE FROM page_list WHERE id = $id LIMIT 1";
    mysqli_query($conn, $query);
    echo "Podstrona została usunięta.";
}


function FormularzLogowania() {
    return '
    <div class="logowanie">
        <h1 class="heading">Panel CMS:</h1>
        <div class="logowanie">
            <form method="post" name="LoginForm" enctype="multipart/form-data" action="' . $_SERVER['REQUEST_URI'] . '">
                <table class="logowanie">
                    <tr><td class="log4_t">[email]</td><td><input type="text" name="login_email" class="logowanie" /></td></tr>
                    <tr><td class="log4_t">[haslo]</td><td><input type="password" name="login_pass" class="logowanie" /></td></tr>
                    <tr><td>&nbsp;</td><td><input type="submit" name="x1_submit" class="logowanie" value="Zaloguj" /></td></tr>
                </table>
            </form>
        </div>
    </div>';
}


echo '<h1>Panel Administracyjny</h1>';
echo '<a href="admin.php?action=add">Dodaj Podstronę</a><br>';
echo '<a href="admin.php?action=list">Lista Podstron</a><br>';


function ListaPodstron() {
    global $conn;
    $query = "SELECT id, page_title FROM page_list ORDER BY id ASC";
    $result = mysqli_query($conn, $query);

    echo '<table>';
    echo '<tr><th>ID</th><th>Tytuł</th><th>Akcje</th></tr>';

    while ($row = mysqli_fetch_assoc($result)) {
        echo '<tr>';
        echo '<td>' . $row['id'] . '</td>';
        echo '<td>' . $row['page_title'] . '</td>';
        echo '<td>
                <a href="admin.php?action=edit&id=' . $row['id'] . '">Edytuj</a> |
                <a href="admin.php?action=delete&id=' . $row['id'] . '">Usuń</a>
              </td>';
        echo '</tr>';
    }

    echo '</table>';
}


function EdytujPodstrone($id) {
    global $conn;
    $query = "SELECT * FROM page_list WHERE id = $id LIMIT 1";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    echo '<form method="post" action="admin.php?action=save&id=' . $id . '">';
    echo '<label>Tytuł:</label><input type="text" name="page_title" value="' . htmlspecialchars($row['page_title']) . '" /><br>';
    echo '<label>Treść:</label><textarea name="page_content">' . htmlspecialchars($row['page_content']) . '</textarea><br>';
    echo '<label>Aktywna:</label><input type="checkbox" name="status" ' . ($row['status'] == 1 ? 'checked' : '') . ' /><br>';
    echo '<input type="submit" value="Zapisz">';
    echo '</form>';
}


function DodajNowaPodstrone() {
    echo '<form method="post" action="admin.php?action=add">';
    echo '<label>Tytuł:</label><input type="text" name="page_title" /><br>';
    echo '<label>Treść:</label><textarea name="page_content"></textarea><br>';
    echo '<label>Aktywna:</label><input type="checkbox" name="status" /><br>';
    echo '<input type="submit" value="Dodaj">';
    echo '</form>';
}


if ($_GET['action'] === 'save' && isset($_GET['id']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_GET['id']);
    $title = mysqli_real_escape_string($conn, $_POST['page_title']);
    $content = mysqli_real_escape_string($conn, $_POST['page_content']);
    $status = isset($_POST['status']) ? 1 : 0;

    $query = "UPDATE page_list SET page_title = '$title', page_content = '$content', status = $status WHERE id = $id";
    if (mysqli_query($conn, $query)) {
        echo "Podstrona została zaktualizowana.";
    } else {
        echo "Błąd podczas aktualizacji: " . mysqli_error($conn);
    }
}

if (isset($_GET['action'])) {
    if ($_GET['action'] === 'list') {
        ListaPodstron();
    } elseif ($_GET['action'] === 'add' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $title = $_POST['page_title'];
        $content = $_POST['page_content'];
        $status = isset($_POST['status']) ? 1 : 0;

        $query = "INSERT INTO page_list (page_title, page_content, status) VALUES ('$title', '$content', $status)";
        mysqli_query($conn, $query);
        echo "Podstrona została dodana.";

    } elseif ($_GET['action'] === 'delete' && isset($_GET['id'])) {
        $id = intval($_GET['id']);
        $query = "DELETE FROM page_list WHERE id = $id LIMIT 1";
        mysqli_query($conn, $query);
        echo "Podstrona została usunięta.";
    }
}

?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Administracyjny</title>
    <link rel="stylesheet" href="../css/CSS.css">
</head>
<body>


</body>
</html>