<?php
    error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);
?>
<html>
<link rel="stylesheet" type="text/css" href="css/CSS.css">


<head>
	<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
	<meta http-equiv="Content-Language" content="pl" />
	<meta name="Author" content="Borys Kutsenko" />
	<title>Największe budynki świata</title>
	<script src="js/kolorujtlo.js"></script>
	<script src="js/timedate.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

</head>
	

<body onload="startclock()">

	<div class="topnav">
  	<a href="index.php?idp=">Strona Główna</a>
	<a href="index.php?idp=BurjKhalifa">Burj Khalifa</a>
	<a href="index.php?idp=Merdeka118">Merdeka 118</a>
	<a href="index.php?idp=ShanghaiTower">Shanghai Tower</a>
	<a href="index.php?idp=MakkahRoyalClockTower">Makkah Royal Clock Tower</a>
	<a href="index.php?idp=Kontakt">Kontakt</a>
	<a href="index.php?idp=filmy">Filmy</a>
	</div>

	<div id = "zegarek"></div>
	<div id = "data"></div>
	<div id = "animacjaTestowa1" class="test-block"> kliknij, a sie powieksze</div>

		<script>
			$("#animacjaTestowa1").on("click", function(){
				$(this).animate({
					width: "500px",
					opacity: 0.4,
					fontSize: "3em",
					borderWidth: "10px"
				}, 1500);
			});

		</script>

	<div id="animacjaTestowa2" class="test-block">Najedz kursorem, a sie powiekszy</div>

		<script>
			$("#animacjaTestowa2").on({
				"mouseover" : function() {
					$(this).animate({
						width: 300
					}, 800);
				},
				"mouseout" : function() {
					$(this).animate({
						width: 200
					}, 800);
				}
			});
		</script>

	<div id="animacjaTestowa3" class="test-block">Klikaj, abym urosl</div>

		<script>
			$("#animacjaTestowa3").on("click", function(){
				if (!$(this).is(":animated")){
					$(this).animate({
						width: "+=" + 50,
						height: "+=" + 10,
						opacity: "-=" + 0.1,
						duration: 3000
					});
				}
			});
		</script>


	<form method = "post" name = "background">
		<input type="button" value = "yelow" onclick="changeBackground('#FFF000')">
	</form>	





<?php
    print_r($_GET);
    if ($_GET['idp'] == '') {
        $strona = 'html/StronaG.html';
    } elseif ($_GET['idp'] == 'BurjKhalifa') {
        $strona = 'html/BurjKhalifa.html';
    } elseif ($_GET['idp'] == 'Merdeka118') {
        $strona = 'html/Merdeka118.html';
    } elseif ($_GET['idp'] == 'ShanghaiTower') {
        $strona = 'html/ShanghaiTower.html';
    } elseif ($_GET['idp'] == 'MakkahRoyalClockTower') {
        $strona = 'html/MakkahRoyalClockTower.html';
    } elseif ($_GET['idp'] == 'Kontakt') {
        $strona = 'html/Kontakt.html';
    }
    elseif ($_GET['idp'] == 'filmy') {
        $strona = 'html/filmy.html';
    }

    if (file_exists($strona)) {
        include($strona);
    }
    else {
        echo "Strona nie została znaleziona.";
    }
?>

<?php
    $nr_indeksu = '170271';
    $nrGrupy = '4';
    echo 'Autor: Borys Kutsenko ' . $nr_indeksu . ' grupa ' . $nrGrupy . '<br /><br />';
?>

	<h2 class="span"></h2>

	<div class="footer">
        <p>&copy; 2024 170271</p>
    </div>

</body>


</html>