<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Administracyjny</title>
    <link rel="stylesheet" href="css/CSS.css">
</head>
<body>
    <h2>Dodaj produkt do koszyka</h2>
    <form class="formik" method="post" action="product.php?action=add">
        <label for="id_prod">ID produktu:</label>
        <input type="number" name="id_prod" id="id_prod" required>
        <br>
        <label style="margin-top: 5px;" for="ile_sztuk">Ilość:</label>
        <input type="number" name="ile_sztuk" id="ile_sztuk" required>
        <br>
        <button class="btn_koncz" style="margin-top: 10px;" type="submit">Dodaj do koszyka</button>
    </form>

    <h2>Twój koszyk</h2>
    <?php

    include('cfg.php');
    session_start();


    function removeFromCart($nr, $conn) {
    if (isset($_SESSION['cart'][$nr])) {
        $product_id = $_SESSION['cart'][$nr]['id_prod'];
        $quantity_to_restore = $_SESSION['cart'][$nr]['ile_sztuk'];


        $query = "UPDATE produkty SET sztuk_w_magazynie = sztuk_w_magazynie + ? WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ii", $quantity_to_restore, $product_id);
        $stmt->execute();


        unset($_SESSION['cart'][$nr]);
    }
}


    // Funkcja dodająca produkt do koszyka
    function addToCart($id_prod, $ile_sztuk, $conn) {
        $query = "SELECT * FROM produkty WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $id_prod);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();

            if ($ile_sztuk <= $row['sztuk_w_magazynie']) {
                // Aktualizacja bazy danych
                $nowa_ilosc = $row['sztuk_w_magazynie'] - $ile_sztuk;
                $update_query = "UPDATE produkty SET sztuk_w_magazynie = ? WHERE id = ?";
                $update_stmt = $conn->prepare($update_query);
                $update_stmt->bind_param("ii", $nowa_ilosc, $id_prod);
                $update_stmt->execute();

                if (!isset($_SESSION['count'])) {
                    $_SESSION['count'] = 1;
                } else {
                    $_SESSION['count']++;
                }

                $nr = $_SESSION['count'];
                $_SESSION['cart'][$nr]['id_prod'] = $id_prod;
                $_SESSION['cart'][$nr]['ile_sztuk'] = $ile_sztuk;
                $_SESSION['cart'][$nr]['data'] = time();
            } else {
                echo "<p style='color: red;'>Niewystarczająca liczba dostępnych jednostek. Dostępne: {$row['sztuk_w_magazynie']}</p>";
            }
        } else {
            echo "<p style='color: red;'>Produkt o ID {$id_prod} nie został znaleziony.</p>";
        }
    }

    // Funkcja zmieniająca ilość produktu w koszyku
    function updateCart($nr, $nowa_ilosc, $conn) {
        if (isset($_SESSION['cart'][$nr])) {
            $id_prod = $_SESSION['cart'][$nr]['id_prod'];
            $query = "SELECT sztuk_w_magazynie FROM produkty WHERE id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("i", $id_prod);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $aktualna_ilosc = $_SESSION['cart'][$nr]['ile_sztuk'];
                $roznica = $nowa_ilosc - $aktualna_ilosc;

                if ($roznica <= $row['sztuk_w_magazynie']) {
                    // Aktualizacja bazy danych
                    $nowa_ilosc_magazyn = $row['sztuk_w_magazynie'] - $roznica;
                    $update_query = "UPDATE produkty SET sztuk_w_magazynie = ? WHERE id = ?";
                    $update_stmt = $conn->prepare($update_query);
                    $update_stmt->bind_param("ii", $nowa_ilosc_magazyn, $id_prod);
                    $update_stmt->execute();

                    $_SESSION['cart'][$nr]['ile_sztuk'] = $nowa_ilosc;
                } else {
                    echo "<p style='color: red;'>Niewystarczająca liczba dostępnych jednostek w magazynie. Dostępne: {$row['sztuk_w_magazynie']}</p>";
                }
            }
        }
    }

    // Funkcja wyświetlająca koszyk
    function showCart($conn) {
        if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
            echo "<p>Koszyk jest pusty.</p>";
            return;
        }

        $total = 0;
        echo '<table border="1" cellpadding="6" cellspacing="0" style="width: 100%; border-collapse: collapse;">';
        echo '<tr>
                <th>ID produktu</th>
                <th>Nazwa</th>
                <th>Ilość</th>
                <th>Cena netto za sztuke</th>
                <th>Podatek VAT</th>
                <th>Cena brutto za wszystko</th>
                <th>Akcje</th>
              </tr>';

        foreach ($_SESSION['cart'] as $nr => $product) {
            $query = "SELECT * FROM produkty WHERE id = " . $product['id_prod'];
            $result = mysqli_query($conn, $query);
            $row = mysqli_fetch_assoc($result);

            if ($row) {
                $cena_netto = $row['cena_netto'];
                $vat = $row['podatek_vat'];
                $cena_brutto = $cena_netto + ($cena_netto * $vat / 100);

                echo '<tr>';
                echo '<td>' . $product['id_prod'] . '</td>';
                echo '<td>' . htmlspecialchars($row['tytul']) . '</td>';
                echo '<td>
                        <form class="form_2" method="post" action="product.php?action=update&nr=' . $nr . '">
                            <input class="cen_net_class" type="number" name="nowa_ilosc" value="' . $product['ile_sztuk'] . '" min="1" style="width: 50px;">
                            <button class="btn_koncz" type="submit">Zmień</button>
                        </form>
                      </td>';
                echo '<td>' . number_format($cena_netto, 2) . ' PLN</td>';
                echo '<td>' . $vat . '%</td>';
                echo '<td>' . number_format($cena_brutto * $product['ile_sztuk'], 2) . ' PLN</td>';
                echo '<td>
                        <a href="product.php?action=remove&nr=' . $nr . '">Usuń</a>
                      </td>';
                echo '</tr>';

                $total += $cena_brutto * $product['ile_sztuk'];
            }
        }

        echo '</table>';
        echo '<p>Łączna wartość produktów: <strong>' . number_format($total, 2) . ' PLN</strong></p>';
    }

    // Obsługa akcji
    if (isset($_GET['action'])) {
        $action = $_GET['action'];

        switch ($action) {
            case 'add':
                if (isset($_POST['id_prod'], $_POST['ile_sztuk'])) {
                    addToCart((int)$_POST['id_prod'], (int)$_POST['ile_sztuk'], $conn);
                }
                break;

            case 'update':
                if (isset($_GET['nr'], $_POST['nowa_ilosc'])) {
                    updateCart((int)$_GET['nr'], (int)$_POST['nowa_ilosc'], $conn);
                }
                break;

            case 'remove':
                if (isset($_GET['nr'])) {
                    removeFromCart($_GET['nr'], $conn);
                }
                break;
        }
    }

    // Wyświetlenie koszyka
    showCart($conn);
    ?>
</body>
</html>
