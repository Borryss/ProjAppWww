<?php
// =======================================
// Konfiguracja projektu
// =======================================
include('../cfg.php');
session_start();

// =======================================
// Obsługa logowania
// =======================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login_email'], $_POST['login_pass'])) {
    // Sprawdzenie danych logowania
    if ($_POST['login_email'] === $login && $_POST['login_pass'] === $pass) {
        $_SESSION['is_logged_in'] = true;
    } else {
        echo "<p>Błędny login lub hasło</p>";
        echo FormularzLogowania();
        exit;
    }
}

// Sprawdzenie czy użytkownik jest zalogowany
if (!isset($_SESSION['is_logged_in']) || $_SESSION['is_logged_in'] !== true) {
    echo FormularzLogowania();
    exit;
}

// =======================================
// Obsługa akcji z GET
// =======================================
if (isset($_GET['action'])) {
    $action = htmlspecialchars($_GET['action']); // Zabezpieczenie zmiennej

    if ($action === 'add') {
        DodajNowaPodstrone();
    } elseif ($action === 'edit' && isset($_GET['id'])) {
        EdytujPodstrone(intval($_GET['id']));
    } elseif ($action === 'delete' && isset($_GET['id'])) {
        $id = intval($_GET['id']); // Zabezpieczenie ID przed SQL Injection
        $query = "DELETE FROM page_list WHERE id = $id LIMIT 1";
        mysqli_query($conn, $query);
        echo "Podstrona została usunięta.";
    } elseif ($action === 'list') {
        ListaPodstron();
    }
}

// =======================================
// Formularz logowania
// =======================================
function FormularzLogowania() {
    return '
    <div class="logowanie">
        <h1 class="heading">Panel CMS:</h1>
        <form method="post" action="' . htmlspecialchars($_SERVER['REQUEST_URI']) . '">
            <table>
                <tr>
                    <td>Email:</td>
                    <td><input type="text" name="login_email" /></td>
                </tr>
                <tr>
                    <td>Hasło:</td>
                    <td><input type="password" name="login_pass" /></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" value="Zaloguj" /></td>
                </tr>
            </table>
        </form>
    </div>';
}

// =======================================
// Wyświetlanie listy podstron
// =======================================
function ListaPodstron() {
    global $conn;
    $query = "SELECT id, page_title FROM page_list ORDER BY id ASC LIMIT 50"; // Zastosowano LIMIT
    $result = mysqli_query($conn, $query);

    echo '<h2>Lista Podstron</h2>';
    echo '<table>';
    echo '<tr><th>ID</th><th>Tytuł</th><th>Akcje</th></tr>';

    while ($row = mysqli_fetch_assoc($result)) {
        echo '<tr>';
        echo '<td>' . htmlspecialchars($row['id']) . '</td>';
        echo '<td>' . htmlspecialchars($row['page_title']) . '</td>';
        echo '<td>
                <a href="admin.php?action=edit&id=' . intval($row['id']) . '">Edytuj</a> |
                <a href="admin.php?action=delete&id=' . intval($row['id']) . '">Usuń</a>
              </td>';
        echo '</tr>';
    }

    echo '</table>';
}

// =======================================
// Formularz edycji podstrony
// =======================================
function EdytujPodstrone($id) {
    global $conn;
    $query = "SELECT * FROM page_list WHERE id = $id LIMIT 1";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);

    echo '<h2>Edytuj Podstronę</h2>';
    echo '<form method="post" action="admin.php?action=save&id=' . intval($id) . '">';
    echo '<label>Tytuł:</label><input type="text" name="page_title" value="' . htmlspecialchars($row['page_title']) . '" /><br>';
    echo '<label>Treść:</label><textarea name="page_content">' . htmlspecialchars($row['page_content']) . '</textarea><br>';
    echo '<label>Aktywna:</label><input type="checkbox" name="status" ' . ($row['status'] == 1 ? 'checked' : '') . ' /><br>';
    echo '<input type="submit" value="Zapisz">';
    echo '</form>';
}

// =======================================
// Formularz dodawania nowej podstrony
// =======================================
function DodajNowaPodstrone() {
    echo '<h2>Dodaj Nową Podstronę</h2>';
    echo '<form method="post" action="admin.php?action=add">';
    echo '<label>Tytuł:</label><input type="text" name="page_title" /><br>';
    echo '<label>Treść:</label><textarea name="page_content"></textarea><br>';
    echo '<label>Aktywna:</label><input type="checkbox" name="status" /><br>';
    echo '<input type="submit" value="Dodaj">';
    echo '</form>';
}

// =======================================
// Zapis podstrony po edycji
// =======================================
if (isset($_GET['action']) && $_GET['action'] === 'save' && isset($_GET['id']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_GET['id']);
    $title = mysqli_real_escape_string($conn, $_POST['page_title']);
    $content = mysqli_real_escape_string($conn, $_POST['page_content']);
    $status = isset($_POST['status']) ? 1 : 0;

    $query = "UPDATE page_list SET page_title = '$title', page_content = '$content', status = $status WHERE id = $id";
    if (mysqli_query($conn, $query)) {
        echo "Podstrona została zaktualizowana.";
    } else {
        echo "Błąd podczas aktualizacji: " . mysqli_error($conn);
    }
}

// =======================================
// Panel administracyjny - linki
// =======================================
echo '<h1>Panel Administracyjny</h1>';
echo '<a href="admin.php?action=add">Dodaj Podstronę</a><br>';
echo '<a href="admin.php?action=list">Lista Podstron</a><br>';





?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Administracyjny</title>
    <link rel="stylesheet" href="../css/CSS.css">
</head>
<body>
