<?php


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

function PokazKontakt() {
    echo '
    <form method="POST" action="">
        <label for="temat">Temat:</label>
        <input type="text" name="temat" required>

        <label for="tresc">Treść wiadomości:</label>
        <textarea name="tresc" required></textarea>

        <label for="email">Twój email:</label>
        <input type="email" name="email" required>

        <input type="submit" name="wyslij" value="Wyślij wiadomość">
    </form>
    ';
}

function PokazPrzypomnienieHasla() {
    echo '
    <form method="POST" action="">
        <label for="email">Podaj swój email do przypomnienia hasła:</label>
        <input type="email" name="email" required>

        <input type="submit" name="przypomnij_haslo" value="Przypomnij hasło">
    </form>
    ';
}

function WyslijMailKontakt() {
    if (empty($_POST['temat']) || empty($_POST['tresc']) || empty($_POST['email'])) {
        echo "Proszę wypełnić wszystkie pola.";
        PokazKontakt();
    } else {
        $odbiorca = $_POST['email'];

        $mail = new PHPMailer(true);

        try {

            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'your-email@gmail.com';
            $mail->Password = 'your-email-password';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;



            $mail->setFrom('your-email@gmail.com', 'Formularz Kontaktowy');
            $mail->addAddress($odbiorca);


            $mail->isHTML(true);
            $mail->Subject = $_POST['temat'];
            $mail->Body    = $_POST['tresc'];


            $mail->send();
            echo 'Wiadomość została wysłana.';
        } catch (Exception $e) {
            echo "Wystąpił błąd podczas wysyłania wiadomości. Error: {$mail->ErrorInfo}";
        }
    }
}

function PrzypomnijHaslo($adminEmail) {
    if (empty($_POST['email'])) {
        echo "Proszę podać swój email.";
    } else {


        $adminPassword = "adminpassword";
        $message = "Twoje hasło do panelu administracyjnego: " . $adminPassword;

        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'your-email@gmail.com';
            $mail->Password = 'your-email-password';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            $mail->setFrom('no-reply@domain.com', 'Przypomnienie Hasla');
            $mail->addAddress($_POST['email']);

            $mail->Subject = 'Przypomnienie hasła';
            $mail->Body    = $message;

            $mail->send();
            echo 'Wiadomość z przypomnieniem hasła została wysłana.';
        } catch (Exception $e) {
            echo "Wystąpił błąd podczas wysyłania przypomnienia. Error: {$mail->ErrorInfo}";
        }
    }
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['wyslij'])) {
        WyslijMailKontakt();
    } elseif (isset($_POST['przypomnij_haslo'])) {
        PrzypomnijHaslo('your-email@gmail.com');
    }
} else {
    PokazKontakt();
    PokazPrzypomnienieHasla();
}

?>
