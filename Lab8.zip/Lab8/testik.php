<?php

    $color = 'green';
    $fruit = 'apple';

?>