<?php
// =======================================
// Dołączenie konfiguracji oraz uruchomienie sesji
// =======================================
include('cfg.php');  // Dołączenie pliku konfiguracyjnego
session_start();  // Uruchomienie sesji, aby przechować informacje o zalogowaniu


// =======================================
// Logowanie użytkownika - obsługa formularza logowania
// =======================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login_email'], $_POST['login_pass'])) {
    // Sprawdzanie, czy podany email i hasło są zgodne z zapisanymi w konfiguracji
    if ($_POST['login_email'] === $login && $_POST['login_pass'] === $pass) {
        $_SESSION['is_logged_in'] = true;  // Ustalenie, że użytkownik jest zalogowany
    } else {
        // Jeżeli dane logowania są błędne, wyświetlamy formularz logowania
        echo "<p>Błędny login lub hasło</p>";
        echo FormularzLogowania();  // Wywołanie funkcji formularza logowania
        exit;
    }
}

// =======================================
// Sprawdzenie, czy użytkownik jest zalogowany
// =======================================
if (!isset($_SESSION['is_logged_in']) || $_SESSION['is_logged_in'] !== true) {
    // Jeżeli użytkownik nie jest zalogowany, wyświetlamy formularz logowania
    echo FormularzLogowania();
    exit;
}

// =======================================
// Funkcja generująca formularz logowania
// =======================================
function FormularzLogowania() {
    // Zwraca formularz logowania HTML
    return '
    <div class="logowanie">
        <h1 class="heading">Panel CMS:</h1>
        <div class="logowanie">
            <form method="post" name="LoginForm" enctype="multipart/form-data" action="' . $_SERVER['REQUEST_URI'] . '">
                <table class="logowanie">
                    <tr><td class="log4_t">[email]</td><td><input type="text" name="login_email" class="logowanie" /></td></tr>
                    <tr><td class="log4_t">[haslo]</td><td><input type="password" name="login_pass" class="logowanie" /></td></tr>
                    <tr><td>&nbsp;</td><td><input type="submit" name="x1_submit" class="logowanie" value="Zaloguj" /></td></tr>
                </table>
            </form>
        </div>
    </div>';
}

echo '<a href="product.php">Produkty</a><br>';




















?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Administracyjny</title>
    <link rel="stylesheet" href="css/CSS.css">  <!-- Dołączenie pliku CSS -->
</head>
<body>
</body>
</html>













